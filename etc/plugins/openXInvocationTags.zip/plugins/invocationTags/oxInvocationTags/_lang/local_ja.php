<?php

/*
+---------------------------------------------------------------------------+
| Revive Adserver                                                           |
| http://www.revive-adserver.com                                            |
|                                                                           |
| Copyright: See the COPYRIGHT.txt file.                                    |
| License: GPLv2 or later, see the LICENSE.txt file.                        |
+---------------------------------------------------------------------------+
*/

$words = array(
    'Local Mode Tag' => 'ローカルモードタグ',
    'Allow Local Mode Tags' => 'ローカルモードタグを許可する',

    'Assign the $phpAds_raw[\'html\'] variable to your template' => 'テンプレートに $phpAds_raw[\'html\'] 変数を指定する',
    
    'Third Party Comment' => '',
    'Cache Buster Comment' => '',
    'SSL Backup Comment' => '',
    'SSL Delivery Comment' => '',
    'Comment' => '',
);

?>