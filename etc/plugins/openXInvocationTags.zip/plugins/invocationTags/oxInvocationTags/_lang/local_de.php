<?php

/*
+---------------------------------------------------------------------------+
| Revive Adserver                                                           |
| http://www.revive-adserver.com                                            |
|                                                                           |
| Copyright: See the COPYRIGHT.txt file.                                    |
| License: GPLv2 or later, see the LICENSE.txt file.                        |
+---------------------------------------------------------------------------+
*/

$words = array(
    'Local Mode Tag' => 'Lokaler Modus Tag',
    'Allow Local Mode Tags' => 'Erlaube Lokalen Modus Tags',

    'Assign the $phpAds_raw[\'html\'] variable to your template' => 'Assign the $phpAds_raw[\'html\'] variable to your template',
    
    'Third Party Comment' => '',
    'Cache Buster Comment' => '',
    'SSL Backup Comment' => '',
    'SSL Delivery Comment' => '',
    'Comment' => '',
);

?>
